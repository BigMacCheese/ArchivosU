var student = /** @class */ (function () {
    function student(nombre, codigo, cedula, edad, direccion, telefono) {
        this.nombre = nombre;
        this.codigo = codigo;
        this.cedula = cedula;
        this.edad = edad;
        this.direccion = direccion;
        this.telefono = telefono;
    }
    return student;
}());
export { student };
