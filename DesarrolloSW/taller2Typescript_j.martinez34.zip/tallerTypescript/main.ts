import { Course } from './course.js';

import { dataCourses } from './dataCourses.js';

import { student } from './student.js';

import { dataStudent } from './dataStudent.js';

let coursesTbody: HTMLElement = document.getElementById('courses')!;
let studentTBody: HTMLElement = document.getElementById('information')!;
const btnfilterByName: HTMLElement = document.getElementById("button-filterByName")!;
const btnfilterByRange: HTMLElement = document.getElementById("button-range")!;
const inputSearchBox: HTMLInputElement = <HTMLInputElement> document.getElementById("search-box")!;
const inputMinimumBox: HTMLInputElement = <HTMLInputElement>document.getElementById("minimum-range")!;
const inputMaximumBox: HTMLInputElement = <HTMLInputElement>document.getElementById("maximum-range")!;
const totalCreditElm: HTMLElement = document.getElementById("total-credits")!;


btnfilterByName.onclick = () => applyFilterByName();
btnfilterByRange.onclick = () => applyFilterCreditsRange();


renderCoursesInTable(dataCourses);
renderStudentInformation(dataStudent);

totalCreditElm.innerHTML = `<p style="text-align: center;"> Número total créditos: ${getTotalCredits(dataCourses)}</p>`;


function renderCoursesInTable(courses: Course[]): void {
  console.log('Desplegando cursos');
  courses.forEach((course) => {
    let trElement = document.createElement("tr");
    trElement.innerHTML = `<td>${course.name}</td>
                           <td>${course.professor}</td>
                           <td>${course.credits}</td>`;
    coursesTbody.appendChild(trElement);
  });
}
 
function renderStudentInformation(studentInfo: student): void{
    let studentElement = document.getElementById("studentName")!;
    let trElement1 = document.createElement("tr");
    let trElement2 = document.createElement("tr");
    let trElement3 = document.createElement("tr");
    let trElement4 = document.createElement("tr");
    let trElement5 = document.createElement("tr");
    trElement1.innerHTML = `<th scope="row">Código</th>
                           <td>${studentInfo.codigo}</td>`
    trElement2.innerHTML = `<th scope="row">Cédula</th>
                           <td>${studentInfo.cedula}</td>`
    trElement3.innerHTML = `<th scope="row">Edad</th>
                            <td>${studentInfo.edad}</td>`
    trElement4.innerHTML = `<th scope="row">Dirección</th>
                            <td>${studentInfo.direccion}</td>`
    trElement5.innerHTML = `<th scope="row">Teléfono</th>
                           <td>${studentInfo.telefono}</td>`;
    studentTBody.appendChild(trElement1);
    studentTBody.appendChild(trElement2);
    studentTBody.appendChild(trElement3);
    studentTBody.appendChild(trElement4);
    studentTBody.appendChild(trElement5);
    studentElement.innerHTML = `${studentInfo.nombre}`;
}

function applyFilterCreditsRange(){
    let strminimum = inputMinimumBox.value;
    let strmaximum = inputMaximumBox.value;
    let minimum: number = (strminimum == null) ? -1: parseInt(strminimum);
    let maximum: number = (strmaximum == null) ? -1: parseInt(strmaximum);
    clearCoursesInTable();
    let coursesFiltered: Course[] = searchCourseByCreditsRange(minimum, maximum, dataCourses);
    renderCoursesInTable(coursesFiltered);

}

function applyFilterByName() { 
  let text = inputSearchBox.value;
  text = (text == null) ? '' : text;
  clearCoursesInTable();
  let coursesFiltered: Course[] = searchCourseByName(text, dataCourses);
  renderCoursesInTable(coursesFiltered);
}

function searchCourseByName(nameKey: string, courses: Course[]) {
  return nameKey === '' ? dataCourses : courses.filter( c => 
    c.name.match(nameKey));
}

function searchCourseByCreditsRange(minimum: number, maximum: number, courses: Course[]){
    return minimum==-1 && maximum == -1? dataCourses : courses.filter(c => c.credits >= minimum && c.credits <= maximum);
}


function getTotalCredits(courses: Course[]): number {
  let totalCredits: number = 0;
  courses.forEach((course) => totalCredits = totalCredits + course.credits);
  return totalCredits;
}

function clearCoursesInTable() {
  while (coursesTbody.hasChildNodes()) {
    if (coursesTbody.firstChild != null) {
      coursesTbody.removeChild(coursesTbody.firstChild);
     
    }
  }
}