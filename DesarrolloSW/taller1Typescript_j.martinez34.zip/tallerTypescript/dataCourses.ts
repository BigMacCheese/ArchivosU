import { Course } from './course.js';

export const dataCourses = [
  new Course("Ingeniería de Sw", "Rubby Casallas", 4),
  new Course("Diseño y análisis de algoritmos", "Jorge Duitama", 2),
  new Course("Sistemas transaccionales", "Claudia Jimenez", 2),
  new Course("English 08", "Patricia Bustos", 1),
  new Course("English 09", "Nataliya Naydenko", 6)
] 
  
